#!/bin/bash

if [ -f /lib/lsb/init-functions ]
then
. /lib/lsb/init-functions
fi


