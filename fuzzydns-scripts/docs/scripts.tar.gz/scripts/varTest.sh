#!/bin/bash

source scriptVars.sh
source scriptfunc.sh



echo $NOW
