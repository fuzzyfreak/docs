#!/bin/bash

conky -d -b -c .conkyrc/conkyrc
