#!/bin/bash
screen -dmS "minecraft" bash -c "sh auto-start.sh"
