#!/bin/bash

source scriptVars.sh
source scriptFunc.sh


server_checker
